﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public int current = 1;
        public int numberOfPages = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void label_curent_Click(object sender, EventArgs e)
        {

        }

        private void button_next_Click(object sender, EventArgs e)
        {
            writeToFile();
            current += 1;
            numberOfPages += 1;
            label_curent.Text = current.ToString();
            readFromFile();
        }

        private void button_prev_Click(object sender, EventArgs e)
        {
            if (current > 1)
            {
                writeToFile();
                current -= 1;
                label_curent.Text = (current.ToString());
                readFromFile();
            }
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            clearBoxes();
            string path = Directory.GetCurrentDirectory();
            if (File.Exists(@path+"\\"+ current.ToString() + ".txt"))
            {
                File.Delete(@path + "\\" + current.ToString() + ".txt");
            }
            
        }
        private void readFromFile()
        {
            TextBox[] boxNames = new TextBox[13]
           {
               textBox_1,
               textBox_2,
               textBox_3,
               textBox_4,
               textBox_5,
               textBox_6,
               textBox_7,
               textBox_8,
               textBox_9,
               textBox_10,
               textBox_11,
               textBox_12,
               textBox_13,
           };
            clearBoxes();
            string pathRead = Directory.GetCurrentDirectory();
            if (File.Exists(@pathRead + "\\" + current.ToString() + ".txt"))
            {
                int currentLine = 0;

                // Read the file and display it line by line.  
                foreach (string line in File.ReadLines(@pathRead + "\\" + current.ToString() + ".txt"))
                {
                    if (currentLine > 12)
                    {
                        textBox_13.Text += line+ Environment.NewLine;
                    }
                    else
                    {
                        boxNames[currentLine].Text = line;
                    }

                    currentLine += 1;
                }
            }
        }
        private void writeToFile()
        {
            string path = Directory.GetCurrentDirectory();
            if (File.Exists(@path + "\\" + current.ToString() + ".txt"))
            {
                File.Delete(@path + "\\" + current.ToString() + ".txt");
            }
            using (StreamWriter writetext = new StreamWriter(current.ToString() + ".txt", true))
            {
                writetext.WriteLine(textBox_1.Text);
                writetext.WriteLine(textBox_2.Text);
                writetext.WriteLine(textBox_3.Text);
                writetext.WriteLine(textBox_4.Text);
                writetext.WriteLine(textBox_5.Text);
                writetext.WriteLine(textBox_6.Text);
                writetext.WriteLine(textBox_7.Text);
                writetext.WriteLine(textBox_8.Text);
                writetext.WriteLine(textBox_9.Text);
                writetext.WriteLine(textBox_10.Text);
                writetext.WriteLine(textBox_11.Text);
                writetext.WriteLine(textBox_12.Text);
                writetext.WriteLine(textBox_13.Text);
            }
        }
        private void clearBoxes()
        {
            textBox_1.Text = "";
            textBox_2.Text = "";
            textBox_3.Text = "";
            textBox_4.Text = "";
            textBox_5.Text = "";
            textBox_6.Text = "";
            textBox_7.Text = "";
            textBox_8.Text = "";
            textBox_9.Text = "";
            textBox_10.Text = "";
            textBox_11.Text = "";
            textBox_12.Text = "";
            textBox_13.Text = "";
        }

        private void deleteAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clearBoxes();
            string path = Directory.GetCurrentDirectory();
            for (int i = 1; i < numberOfPages+1; i++)
            {
                if (File.Exists(@path + "\\" + i.ToString() + ".txt"))
                {
                    File.Delete(@path + "\\" + i.ToString() + ".txt");
                }
            }
            current = 1;
            numberOfPages = 1;
            label_curent.Text = current.ToString();
        }
    }
}

