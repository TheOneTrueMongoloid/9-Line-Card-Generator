﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label_main = new System.Windows.Forms.Label();
            this.label_curent = new System.Windows.Forms.Label();
            this.label_1 = new System.Windows.Forms.Label();
            this.label_2 = new System.Windows.Forms.Label();
            this.label_2_2 = new System.Windows.Forms.Label();
            this.label_3 = new System.Windows.Forms.Label();
            this.label_4 = new System.Windows.Forms.Label();
            this.label_5 = new System.Windows.Forms.Label();
            this.label_6 = new System.Windows.Forms.Label();
            this.label_7 = new System.Windows.Forms.Label();
            this.label7_2 = new System.Windows.Forms.Label();
            this.label_8 = new System.Windows.Forms.Label();
            this.label8_2 = new System.Windows.Forms.Label();
            this.label_9 = new System.Windows.Forms.Label();
            this.label_notes = new System.Windows.Forms.Label();
            this.textBox_1 = new System.Windows.Forms.TextBox();
            this.textBox_2 = new System.Windows.Forms.TextBox();
            this.textBox_4 = new System.Windows.Forms.TextBox();
            this.textBox_5 = new System.Windows.Forms.TextBox();
            this.textBox_6 = new System.Windows.Forms.TextBox();
            this.textBox_7 = new System.Windows.Forms.TextBox();
            this.textBox_8 = new System.Windows.Forms.TextBox();
            this.textBox_10 = new System.Windows.Forms.TextBox();
            this.textBox_12 = new System.Windows.Forms.TextBox();
            this.textBox_3 = new System.Windows.Forms.TextBox();
            this.textBox_9 = new System.Windows.Forms.TextBox();
            this.textBox_11 = new System.Windows.Forms.TextBox();
            this.textBox_13 = new System.Windows.Forms.TextBox();
            this.button_prev = new System.Windows.Forms.Button();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_next = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_main
            // 
            this.label_main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_main.Font = new System.Drawing.Font("Calibri", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_main.Location = new System.Drawing.Point(32, 24);
            this.label_main.Name = "label_main";
            this.label_main.Size = new System.Drawing.Size(648, 40);
            this.label_main.TabIndex = 0;
            this.label_main.Text = "CAS 9-LINE CARD";
            this.label_main.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_curent
            // 
            this.label_curent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_curent.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_curent.Location = new System.Drawing.Point(680, 24);
            this.label_curent.Name = "label_curent";
            this.label_curent.Size = new System.Drawing.Size(44, 40);
            this.label_curent.TabIndex = 1;
            this.label_curent.Text = "1";
            this.label_curent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_curent.Click += new System.EventHandler(this.label_curent_Click);
            // 
            // label_1
            // 
            this.label_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_1.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_1.Location = new System.Drawing.Point(32, 64);
            this.label_1.Name = "label_1";
            this.label_1.Size = new System.Drawing.Size(44, 40);
            this.label_1.TabIndex = 2;
            this.label_1.Text = "1";
            this.label_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_2
            // 
            this.label_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_2.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_2.Location = new System.Drawing.Point(32, 104);
            this.label_2.Name = "label_2";
            this.label_2.Size = new System.Drawing.Size(44, 40);
            this.label_2.TabIndex = 3;
            this.label_2.Text = "2";
            this.label_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_2_2
            // 
            this.label_2_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_2_2.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_2_2.Location = new System.Drawing.Point(32, 144);
            this.label_2_2.Name = "label_2_2";
            this.label_2_2.Size = new System.Drawing.Size(44, 40);
            this.label_2_2.TabIndex = 4;
            this.label_2_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_3
            // 
            this.label_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_3.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_3.Location = new System.Drawing.Point(32, 184);
            this.label_3.Name = "label_3";
            this.label_3.Size = new System.Drawing.Size(44, 40);
            this.label_3.TabIndex = 5;
            this.label_3.Text = "3";
            this.label_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_4
            // 
            this.label_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_4.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_4.Location = new System.Drawing.Point(32, 224);
            this.label_4.Name = "label_4";
            this.label_4.Size = new System.Drawing.Size(44, 40);
            this.label_4.TabIndex = 6;
            this.label_4.Text = "4";
            this.label_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_5
            // 
            this.label_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_5.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_5.Location = new System.Drawing.Point(32, 264);
            this.label_5.Name = "label_5";
            this.label_5.Size = new System.Drawing.Size(44, 40);
            this.label_5.TabIndex = 7;
            this.label_5.Text = "5";
            this.label_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_6
            // 
            this.label_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_6.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_6.Location = new System.Drawing.Point(32, 304);
            this.label_6.Name = "label_6";
            this.label_6.Size = new System.Drawing.Size(44, 40);
            this.label_6.TabIndex = 8;
            this.label_6.Text = "6";
            this.label_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_7
            // 
            this.label_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_7.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_7.Location = new System.Drawing.Point(32, 344);
            this.label_7.Name = "label_7";
            this.label_7.Size = new System.Drawing.Size(44, 40);
            this.label_7.TabIndex = 9;
            this.label_7.Text = "7";
            this.label_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7_2
            // 
            this.label7_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7_2.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7_2.Location = new System.Drawing.Point(32, 384);
            this.label7_2.Name = "label7_2";
            this.label7_2.Size = new System.Drawing.Size(44, 40);
            this.label7_2.TabIndex = 10;
            this.label7_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_8
            // 
            this.label_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_8.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_8.Location = new System.Drawing.Point(32, 424);
            this.label_8.Name = "label_8";
            this.label_8.Size = new System.Drawing.Size(44, 40);
            this.label_8.TabIndex = 11;
            this.label_8.Text = "8";
            this.label_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8_2
            // 
            this.label8_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8_2.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8_2.Location = new System.Drawing.Point(32, 464);
            this.label8_2.Name = "label8_2";
            this.label8_2.Size = new System.Drawing.Size(44, 40);
            this.label8_2.TabIndex = 12;
            this.label8_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_9
            // 
            this.label_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_9.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_9.Location = new System.Drawing.Point(32, 504);
            this.label_9.Name = "label_9";
            this.label_9.Size = new System.Drawing.Size(44, 40);
            this.label_9.TabIndex = 13;
            this.label_9.Text = "9";
            this.label_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_notes
            // 
            this.label_notes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_notes.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_notes.Location = new System.Drawing.Point(32, 544);
            this.label_notes.Name = "label_notes";
            this.label_notes.Size = new System.Drawing.Size(688, 40);
            this.label_notes.TabIndex = 14;
            this.label_notes.Text = "  NOTES:";
            this.label_notes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_1
            // 
            this.textBox_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_1.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_1.Location = new System.Drawing.Point(80, 64);
            this.textBox_1.Multiline = true;
            this.textBox_1.Name = "textBox_1";
            this.textBox_1.Size = new System.Drawing.Size(640, 40);
            this.textBox_1.TabIndex = 1;
            // 
            // textBox_2
            // 
            this.textBox_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_2.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_2.Location = new System.Drawing.Point(80, 104);
            this.textBox_2.Multiline = true;
            this.textBox_2.Name = "textBox_2";
            this.textBox_2.Size = new System.Drawing.Size(640, 40);
            this.textBox_2.TabIndex = 2;
            // 
            // textBox_4
            // 
            this.textBox_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_4.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_4.Location = new System.Drawing.Point(80, 184);
            this.textBox_4.Multiline = true;
            this.textBox_4.Name = "textBox_4";
            this.textBox_4.Size = new System.Drawing.Size(640, 40);
            this.textBox_4.TabIndex = 4;
            // 
            // textBox_5
            // 
            this.textBox_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_5.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_5.Location = new System.Drawing.Point(80, 224);
            this.textBox_5.Multiline = true;
            this.textBox_5.Name = "textBox_5";
            this.textBox_5.Size = new System.Drawing.Size(640, 40);
            this.textBox_5.TabIndex = 5;
            // 
            // textBox_6
            // 
            this.textBox_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_6.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_6.Location = new System.Drawing.Point(80, 264);
            this.textBox_6.Multiline = true;
            this.textBox_6.Name = "textBox_6";
            this.textBox_6.Size = new System.Drawing.Size(640, 40);
            this.textBox_6.TabIndex = 6;
            // 
            // textBox_7
            // 
            this.textBox_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_7.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_7.Location = new System.Drawing.Point(80, 304);
            this.textBox_7.Multiline = true;
            this.textBox_7.Name = "textBox_7";
            this.textBox_7.Size = new System.Drawing.Size(640, 40);
            this.textBox_7.TabIndex = 7;
            // 
            // textBox_8
            // 
            this.textBox_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_8.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_8.Location = new System.Drawing.Point(80, 344);
            this.textBox_8.Multiline = true;
            this.textBox_8.Name = "textBox_8";
            this.textBox_8.Size = new System.Drawing.Size(640, 40);
            this.textBox_8.TabIndex = 8;
            // 
            // textBox_10
            // 
            this.textBox_10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_10.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_10.Location = new System.Drawing.Point(80, 424);
            this.textBox_10.Multiline = true;
            this.textBox_10.Name = "textBox_10";
            this.textBox_10.Size = new System.Drawing.Size(640, 40);
            this.textBox_10.TabIndex = 10;
            // 
            // textBox_12
            // 
            this.textBox_12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_12.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_12.Location = new System.Drawing.Point(80, 504);
            this.textBox_12.Multiline = true;
            this.textBox_12.Name = "textBox_12";
            this.textBox_12.Size = new System.Drawing.Size(640, 40);
            this.textBox_12.TabIndex = 12;
            // 
            // textBox_3
            // 
            this.textBox_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_3.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_3.Location = new System.Drawing.Point(80, 144);
            this.textBox_3.Multiline = true;
            this.textBox_3.Name = "textBox_3";
            this.textBox_3.Size = new System.Drawing.Size(640, 40);
            this.textBox_3.TabIndex = 3;
            // 
            // textBox_9
            // 
            this.textBox_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_9.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_9.Location = new System.Drawing.Point(80, 384);
            this.textBox_9.Multiline = true;
            this.textBox_9.Name = "textBox_9";
            this.textBox_9.Size = new System.Drawing.Size(640, 40);
            this.textBox_9.TabIndex = 9;
            // 
            // textBox_11
            // 
            this.textBox_11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_11.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_11.Location = new System.Drawing.Point(80, 464);
            this.textBox_11.Multiline = true;
            this.textBox_11.Name = "textBox_11";
            this.textBox_11.Size = new System.Drawing.Size(640, 40);
            this.textBox_11.TabIndex = 11;
            // 
            // textBox_13
            // 
            this.textBox_13.AcceptsReturn = true;
            this.textBox_13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_13.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_13.Location = new System.Drawing.Point(32, 584);
            this.textBox_13.Multiline = true;
            this.textBox_13.Name = "textBox_13";
            this.textBox_13.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_13.Size = new System.Drawing.Size(688, 336);
            this.textBox_13.TabIndex = 13;
            // 
            // button_prev
            // 
            this.button_prev.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_prev.Location = new System.Drawing.Point(32, 920);
            this.button_prev.Name = "button_prev";
            this.button_prev.Size = new System.Drawing.Size(232, 48);
            this.button_prev.TabIndex = 14;
            this.button_prev.Text = "PREV";
            this.button_prev.UseVisualStyleBackColor = true;
            this.button_prev.Click += new System.EventHandler(this.button_prev_Click);
            // 
            // button_clear
            // 
            this.button_clear.ContextMenuStrip = this.contextMenuStrip1;
            this.button_clear.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clear.Location = new System.Drawing.Point(264, 920);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(224, 48);
            this.button_clear.TabIndex = 15;
            this.button_clear.Text = "CLEAR";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_next
            // 
            this.button_next.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_next.Location = new System.Drawing.Point(488, 920);
            this.button_next.Name = "button_next";
            this.button_next.Size = new System.Drawing.Size(232, 48);
            this.button_next.TabIndex = 16;
            this.button_next.Text = "NEXT";
            this.button_next.UseVisualStyleBackColor = true;
            this.button_next.Click += new System.EventHandler(this.button_next_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteAllToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(125, 26);
            // 
            // deleteAllToolStripMenuItem
            // 
            this.deleteAllToolStripMenuItem.Name = "deleteAllToolStripMenuItem";
            this.deleteAllToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.deleteAllToolStripMenuItem.Text = "Delete All";
            this.deleteAllToolStripMenuItem.Click += new System.EventHandler(this.deleteAllToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 1023);
            this.Controls.Add(this.button_next);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_prev);
            this.Controls.Add(this.textBox_13);
            this.Controls.Add(this.textBox_11);
            this.Controls.Add(this.textBox_9);
            this.Controls.Add(this.textBox_3);
            this.Controls.Add(this.textBox_12);
            this.Controls.Add(this.textBox_10);
            this.Controls.Add(this.textBox_8);
            this.Controls.Add(this.textBox_7);
            this.Controls.Add(this.textBox_6);
            this.Controls.Add(this.textBox_5);
            this.Controls.Add(this.textBox_4);
            this.Controls.Add(this.textBox_2);
            this.Controls.Add(this.textBox_1);
            this.Controls.Add(this.label_notes);
            this.Controls.Add(this.label_9);
            this.Controls.Add(this.label8_2);
            this.Controls.Add(this.label_8);
            this.Controls.Add(this.label7_2);
            this.Controls.Add(this.label_7);
            this.Controls.Add(this.label_6);
            this.Controls.Add(this.label_5);
            this.Controls.Add(this.label_4);
            this.Controls.Add(this.label_3);
            this.Controls.Add(this.label_2_2);
            this.Controls.Add(this.label_2);
            this.Controls.Add(this.label_1);
            this.Controls.Add(this.label_curent);
            this.Controls.Add(this.label_main);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_main;
        private System.Windows.Forms.Label label_curent;
        private System.Windows.Forms.Label label_1;
        private System.Windows.Forms.Label label_2;
        private System.Windows.Forms.Label label_2_2;
        private System.Windows.Forms.Label label_3;
        private System.Windows.Forms.Label label_4;
        private System.Windows.Forms.Label label_5;
        private System.Windows.Forms.Label label_6;
        private System.Windows.Forms.Label label_7;
        private System.Windows.Forms.Label label7_2;
        private System.Windows.Forms.Label label_8;
        private System.Windows.Forms.Label label8_2;
        private System.Windows.Forms.Label label_9;
        private System.Windows.Forms.Label label_notes;
        private System.Windows.Forms.TextBox textBox_1;
        private System.Windows.Forms.TextBox textBox_2;
        private System.Windows.Forms.TextBox textBox_4;
        private System.Windows.Forms.TextBox textBox_5;
        private System.Windows.Forms.TextBox textBox_6;
        private System.Windows.Forms.TextBox textBox_7;
        private System.Windows.Forms.TextBox textBox_8;
        private System.Windows.Forms.TextBox textBox_10;
        private System.Windows.Forms.TextBox textBox_12;
        private System.Windows.Forms.TextBox textBox_3;
        private System.Windows.Forms.TextBox textBox_9;
        private System.Windows.Forms.TextBox textBox_11;
        private System.Windows.Forms.TextBox textBox_13;
        private System.Windows.Forms.Button button_prev;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_next;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteAllToolStripMenuItem;
    }
}

